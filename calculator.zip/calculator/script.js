// Function to display values on the calculator screen
function display(value) {
    document.getElementById("result").value += value;
}

// Function to clear the screen
function clearScreen() {
    document.getElementById("result").value = "";
}

// Function to delete the last digit
function deleteDigit() {
    let currentValue = document.getElementById("result").value;
    document.getElementById("result").value = currentValue.slice(0, -1);
}

// Function to calculate the result
function calculate() {
    let currentValue = document.getElementById("result").value;
    if (currentValue) {
        try {
            document.getElementById("result").value = eval(currentValue);
        } catch (e) {
            document.getElementById("result").value = "Error";
        }
    }
}

// Adding keyboard support for calculator input
document.addEventListener('keydown', function(event) {
    const key = event.key;
    const resultField = document.getElementById("result");

    if ((key >= 0 && key <= 9) || key === '.' || key === '+' || key === '-' || key === '*' || key === '/') {
        display(key);
    } else if (key === 'Enter') {
        calculate();
    } else if (key === 'Backspace') {
        deleteDigit();
    } else if (key === 'Escape') {
        clearScreen();
    }
});

